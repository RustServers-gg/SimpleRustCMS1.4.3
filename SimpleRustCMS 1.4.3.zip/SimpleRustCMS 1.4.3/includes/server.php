<section class="server">
		<h3 class="block-title"><?php echo $s1_name; ?></h3>
		<div class="card grid grid-3">

			<div>
				<div class="card-item">
					<p><i class="fas fa-map"></i></p>
					<?php echo $s1_map; ?>
				</div>
				<div class="card-item">
					<p><i class="fas fa-users"></i></p>
					<p><?php echo $s1_cur; ?>	/ <?php echo $s1_max; ?></p>
				</div>
				<div class="card-item">
				<p><i class="fa-solid fa-signal"></i></p>
					<p><?php echo $s1_uptime ?>%</p>
				</div>
				<div class="card-item">
					<p><i class="fas fa-cloud"></i></p>
					
					<p>
					<?php echo $s1_status; ?>
					</p>
					
				</div>
			</div>

			<div>
				<div class="card-item">
				<p><i class="fa-solid fa-check-to-slot"></i> </p>
					<p></p> <p class="color-green"><?php echo $s1_votes; ?></p>
				</div>
				<div class="card-item">
				<p><i class="fa-solid fa-map-location"></i></p>
					<p></p> <p><?php echo $s1_location; ?></p>
				</div>
				<div class="card-item">
				<p><i class="fa-solid fa-ranking-star"></i></p>
					<p></p> <p><?php echo $s1_rank; ?></p>
				</div>
				<div class="card-item">
					<p><i class="fa-regular fa-heart"></i></p>
					<p></p> <p class="color-red"><?php echo $s1_favorited; ?></p>
				</div>
			</div>

			<div class="ctas">
			<a href="<?= $s1_url ?>" class="cta cta-vote"> 🏆VOTE </a>
              <a href="<?= $SRV_SHOP ?>" class="cta cta-primary">⭐️BUY VIP</a>
              <a href="steam://connect/<?= $s1_ip .":" . $s1_port ?>" class="cta cta-secondary">🎮CONNECT</a>
			</div>

		</div>
	</section>

	<section class="server">
	<h3 class="block-title"><?php echo $s2_name; ?></h3>
		<div class="card grid grid-3">

			<div>
				<div class="card-item">
					<p><i class="fas fa-map"></i></p>
					<?php echo $s2_map; ?>
				</div>
				<div class="card-item">
					<p><i class="fas fa-users"></i></p>
					<p><?php echo $s2_cur; ?>	/ <?php echo $s2_max; ?></p>
				</div>
				<div class="card-item">
				<p><i class="fa-solid fa-signal"></i></p>
					<p><?php echo $s2_uptime ?>%</p>
				</div>
				<div class="card-item">
					<p><i class="fas fa-cloud"></i></p>
					
					<p>
					<?php echo $s2_status; ?>
					</p>
					
				</div>
			</div>

			<div>
				<div class="card-item">
				<p><i class="fa-solid fa-check-to-slot"></i> </p>
					<p></p> <p class="color-green"><?php echo $s2_votes; ?></p>
				</div>
				<div class="card-item">
				<p><i class="fa-solid fa-map-location"></i></p>
					<p></p> <p><?php echo $s2_location; ?></p>
				</div>
				<div class="card-item">
				<p><i class="fa-solid fa-ranking-star"></i></p>
					<p></p> <p><?php echo $s2_rank; ?></p>
				</div>
				<div class="card-item">
					<p><i class="fa-regular fa-heart"></i></p>
					<p></p> <p class="color-red"><?php echo $s2_favorited; ?></p>
				</div>
			</div>

			<div class="ctas">
			<a href="<?= $s2_url ?>" class="cta cta-vote"> 🏆VOTE </a>
              <a href="<?= $SRV_SHOP ?>" class="cta cta-primary">⭐️BUY VIP</a>
              <a href="steam://connect/<?= $s2_ip .":" . $s2_port ?>" class="cta cta-secondary">🎮CONNECT</a>
			</div>

		</div>

		</div>
	</section>