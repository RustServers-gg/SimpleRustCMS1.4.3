<?php include "config.php"?>

<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="<?php echo "{$SRV_GOOGLE_DESCRIPTION}";?>">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/main.css">
<script type="text/javascript" src="js/wombat.js" charset="utf-8"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.css" type="text/css">
  <title><?php   
  
  echo "{$SRV_GOOGLE_TITLE}";
  
  ?>
  </title>


  <script>
	tinymce.init({
		selector: '#comment',
		plugins: 'link',
		toolbar: 'link emoticons bold',
		skin: 'oxide-dark',
		content_css: "dark"
	});
</script>


</head>