<button id="mobile-open" class="mobile-btn"><i class="fas fa-bars"></i></button>

	<nav class="nav" role="navigation">
		<button id="mobile-close" class="mobile-btn"><i class="fas fa-times"></i></button>
		<div class="nav-container">
			<div>
				
				<p>There are currently <b><font color="green"> <?php  echo  $s1_cur + $s2_cur ?> </font></b> playing <?php echo $SRV_NAME  ?>!</p>
				
			</div>

			<div>
				<ul>
				<li><a href="<?= $HOME_URL ?>"><i class="fas fa-home"></i> HOME</a></li>
					<li><a href="<?= $SRV_DiSCORD_INVITE ?>"><i class="fab fa-discord"></i> DISCORD</a></li>
					<li><a href="<?= $SRV_SHOP ?>"><i class="fas fa-shopping-cart"></i> SHOP</a></li>
				</ul>
			</div>
		</div>
	</nav>