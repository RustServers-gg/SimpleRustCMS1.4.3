<main>
	<section class="header">
		<div class="grid grid-2">
			<div class="logo">
				<img src="images/logo.png" alt="logo">
			</div>

			<div class="text-content">
				<h1><?php
				echo "$SRV_NAME";
			?>
</h1>
				<p><?php echo "$SRV_NAME";?> <?php echo "$SRV_ABOUT" ?></p>
			</div>
		</div>
	</section>

	<section class="quicklinks">
		<div class="grid grid-3">
			<div>
				<a class="flex align-center" href="<?= $SRV_STEAM ?>" target="_blank">
					<div>
						<i class="fab fa-steam color-orange"></i>
					</div>
					<div class="column">
						<h2>STEAM</h2>
						<p>Join our Steam Group!</p>
					</div>
				</a>
			</div>

			<div>
				<a class="flex align-center" href="<?= $SRV_DiSCORD_INVITE?>">
					<div>
						<i class="i fab fa-discord color-blue"></i>
					</div>
					<div class="column">
						<h2>DISCORD</h2>
						<p>Join the conversation!</p>
					</div>
				</a>
			</div>

			<div>
				<a class="flex align-center" href="<?= $SRV_SHOP?>">
					<div>
						<i class="fas fa-shopping-cart color-green"></i>
					</div>
					<div class="column">
						<h2>SHOP</h2>
						<p>Support the servers!</p>
					</div>
				</a>
			</div>
		</div>
	</section>

	<section class="news">
		<div class="grid grid-2">
			<div class="latest-news">
				<h3 class="block-title">Latest News</h3>
				
				<div class="news-article">
					<article>
						<h3>10x Update</h3>
						<p><p>We've done some changes to the 10x Server.</p>
...</p>
						<a href="#" class="read-more"><i class="far fa-newspaper"></i></a>
					</article>
				</div>
				
				<div class="news-article">
					<article>
						<h3>10x Server Under Construction</h3>
						<p>We've started to configure a 10x Vanilla Server. 
...</p>
						<a href="#" class="read-more"><i class="far fa-newspaper"></i></a>
					</article>
				</div>
				
				<div class="news-article">
					<article>
						<h3>Drones coming to Rust</h3>
						<p><p>The next update appears to be bringing us drone...</p>
						<a href="#" class="read-more"><i class="far fa-newspaper"></i></a>
					</article>
				</div>
				
				<div class="news-article">
					<article>
						<h3>New server wiped and ready!</h3>
						<p><p><strong>Go check out our new server on a new ma...</p>
						<a href="#" class="read-more"><i class="far fa-newspaper"></i></a>
					</article>
				</div>
				
			</div>
			<div>
				<h3 class="block-title">Featured Video</h3>
				<iframe width="100%" height="306"
				src="<?= $YOUTUBE_VID?>">
</iframe>
			</div>
		</div>
	</section>