<footer class="footer">
	<div class="content">
		<div class="grid grid-2">
			<div>
				<h4><?php echo "$FOOTER" ?></h4>
				<ul>
				<li><a href="<?= $HOME_URL ?>"><i class="fas fa-home"></i> HOME</a></li>
					<li><a href="<?= $SRV_DiSCORD_INVITE ?>"><i class="fab fa-discord"></i> DISCORD</a></li>
					<li><a href="<?= $SRV_SHOP ?>"><i class="fas fa-shopping-cart"></i> SHOP</a></li>
				</ul>
			</div>
			<div class="logo">
				<img src="images/logo.png" alt="logo">
			</div>
		</div>
	</div>
</footer>