var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

if (document.body.classList.contains('admin')) {
	const pBtn = document.getElementById('aPublish');
	const eBtn = document.getElementById('sEmbed');
	const wBtn = document.getElementById('wStats');

	const publish = document.querySelector('.admin-news');
	const embed = document.querySelector('.admin-embed');
	const wipe = document.querySelector('.admin-wipe');

	const active = localStorage.getItem('activePanel');

	pBtn.addEventListener('click', () => {
		publish.classList.add('visible');
		embed.classList.remove('visible');
		wipe.classList.remove('visible');
		localStorage.setItem('activePanel', 'publish');
	});

	eBtn.addEventListener('click', () => {
		publish.classList.remove('visible');
		embed.classList.add('visible');
		wipe.classList.remove('visible');
		localStorage.setItem('activePanel', 'embed');
	});

	wBtn.addEventListener('click', () => {
		publish.classList.remove('visible');
		embed.classList.remove('visible');
		wipe.classList.add('visible');
		localStorage.setItem('activePanel', 'wipe');
	});

	if (active === 'publish') {
		publish.classList.add('visible');
		embed.classList.remove('visible');
		wipe.classList.remove('visible');
	} else if (active === 'embed') {
		embed.classList.add('visible');
		publish.classList.remove('visible');
		wipe.classList.remove('visible');
	} else if (active === 'wipe') {
		embed.classList.remove('visible');
		publish.classList.remove('visible');
		wipe.classList.add('visible');
	}
}

const open = document.getElementById('mobile-open');
const close = document.getElementById('mobile-close');
const nav = document.querySelector('.nav');

open.addEventListener('click', () => {
	nav.classList.add('nav-height');
});

close.addEventListener('click', () => {
	nav.classList.remove('nav-height');
});





}
