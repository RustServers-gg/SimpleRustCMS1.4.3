<?php include "includes/header.php" ?>
<?php include "includes.php" ?>
<?php include "includes/articles.php" ?>

<body>


	
	<!-- Navigation -->

	<?php include "includes/navigation.php" ?>
	

<!-- Main Section Home -->

<?php include "includes/main.php" ?>


<!-- Servers Section -->


	<?php include "includes/server.php" ?>



<!-- TBA Stats -->

	<!-- <section class="stats">
		<h3>Server TOP 20</h3>
		<ol>
			<li>
				<strong class="left">Player</strong>
				<strong class="center">Kills</strong>
				<strong class="center">Deaths</strong>
				<strong class="center">KDR</strong>
				<strong class="right">Playtime</strong>
			</li>
		</ol>
		<ol>
			
		</ol>
	</section> -->

<!-- don't remove this main tag -->

</main>

<?php include "includes/footer.php" ?>


<script src="js/scripts.js"></script>
</body>






</body>
</html>
