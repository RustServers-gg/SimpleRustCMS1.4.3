<?php
//Server Name
$SRV_NAME = "RustServer";
//Google Title
$SRV_GOOGLE_TITLE = "$SRV_NAME - Home";
//Google Description
$SRV_GOOGLE_DESCRIPTION = "The best Rust servers founded in 2022";

//Home URL
$HOME_URL ="/";

//Language



//Server Description
$SRV_ABOUT = "is a Rust gaming community found in late 2022. Our goal is to develop our server according
to our players wishes. We do not build this for us, we build it for you. We’ll take care of the
backend and let you as a community take care of the front
We are open for suggestions and feedback. Let us know what YOU want!";
//Footer Text 
$FOOTER = "©Development by Hyper#1670";
//Steam Group Link
$SRV_STEAM= "https://steamcommunity.com";
//Discord Invite Link (Public)
$SRV_DiSCORD_INVITE= "https://discord.com/invite/rustgroups";
//Shop URL (Your Tebex Shop)
$SRV_SHOP= "https://rustgroups.tebex.io";
//YOUTUBE VIDEO MAKE SURE you keep in embed, replace the aOTOIfQ1 part with the video you desire
$YOUTUBE_VID ="https://www.youtube.com/embed/aOTOIfQ1__w?controls=0";

// BELOW YOUF FIND EVERYTHING TO SHOW PLAYER COUNT ON THE WEBSITE
// Please make sure everything is filled out correctly

// Server Status Module V2 Config (rust-servers.net)
//======================================================================

//-----------------------------------------------------
// Server #1
//-----------------------------------------------------

	define( "SERVER_1_KEY","fkil0HQ6V8Blf3PBBM4rwkEkl2dgG5DwrhN" ); // REQUIRED
	# Your server #1 API Key (Rust-Servers.Net)
	define( "SERVER_1_DESC" , "This is short server description. Vanilla, Cool admins, etc." );
	# Your server #1 description

//-----------------------------------------------------
// Server #2
//-----------------------------------------------------

	define( "SERVER_2_KEY","fkil0HQ6V8Blf3PBBM4rwkEkl2dgG5DwrhN" ); // REQUIRED
	# Your server #2 API Key (Rust-Servers.Net)
	define( "SERVER_2_DESC" , "This is short server description. Vanilla, Cool admins, etc." );
	# Your server #2 description

//IN ORDER to create more Servers you need to edit includes.php as well, if you need support with this contact me if needed Hyper#1670 on discord



	



?>


